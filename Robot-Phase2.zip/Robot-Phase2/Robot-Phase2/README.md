# Robot Phase 2

Run this command in the extracted Robot-Phase2 directory with Python 3:

```sh
python generate.py Robot-Phase2.iml.json sketches
```

The generator reads the corrected course-tool export directly. It writes a matching folder and .ino file for ObstacleStop, LineFollower, AllFeatures, ScenarioA, ScenarioB, ScenarioC, and ScenarioD_Patrol. The deliberately invalid instance is retained in the model and excluded by its instance name. Make configuration changes in the model, then regenerate.

## Design and verification

Generator-Design-Notes.pdf maps the corrected metamodel to the sketch and records changes and validation rules. Seven C++ syntax checks with stub Arduino and FastLED APIs passed. The generated files matched a fresh generation, and changing PatrolBot's LED interval in the exported model changed its generated constant.

The pin layout for Scenario D assumes the Arduino Uno and follows the published ELEGOO Smart Robot Car V4.0 New DeviceDriverSet.h. Analog channels are stored as 16 (A2), 15 (A1), and 14 (A0) to match the model's INT type. Scenario D uses motor enable D3, left PWM D6/direction D8, right PWM D5/direction D7, trigger D13, echo D12, and LED D4. Compare these assignments and the generated ultrasonic routine, line threshold polarity, and WS2812 GRB convention against your course starter and kit before upload.

https://github.com/elegooofficial/ELEGOO-Smart-Robot-Car-Kit-V4.0-New/blob/main/DeviceDriverSet.h

## Arduino IDE and video

1. Open each .ino in Arduino IDE, select your board, install FastLED, and click Verify. The Arduino IDE build and course-tool import have not been run here.
2. Upload ScenarioD_Patrol to the kit and open Serial Monitor at 9600 baud. Reset to show PatrolBot's startup information.
3. In 30 seconds or less, show the blinking blue LED and startup output, then put a hand in front of the ultrasonic sensor and dark tape beneath a line channel to show the readings change. The generated default loop leaves the motors stopped.
